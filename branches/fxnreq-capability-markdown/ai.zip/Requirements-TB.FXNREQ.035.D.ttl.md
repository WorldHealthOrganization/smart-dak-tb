#  Manage TB treatment interruptions - TTL Representation - SMART DAK TB v1.0.2

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* ** Manage TB treatment interruptions**

## : Manage TB treatment interruptions - TTL Representation

| |
| :--- |
| Active as of 2026-11-18 |

[Raw ttl](Requirements-TB.FXNREQ.035.D.ttl) | [Download](Requirements-TB.FXNREQ.035.D.ttl)

