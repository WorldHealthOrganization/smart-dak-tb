#  Receive the client - JSON Representation - SMART DAK TB v1.0.2

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* ** Receive the client**

## : Receive the client - JSON Representation

| |
| :--- |
| Active as of 2026-11-18 |

[Raw json](Requirements-TB.FXNREQ.051.F.json) | [Download](Requirements-TB.FXNREQ.051.F.json)

