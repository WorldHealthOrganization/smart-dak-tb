# Allow for offline and online functionality - JSON Representation - SMART DAK TB v1.0.2

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Allow for offline and online functionality**

## : Allow for offline and online functionality - JSON Representation

| |
| :--- |
| Active as of 2026-11-18 |

[Raw json](Requirements-TB.NFXNREQ.041.json) | [Download](Requirements-TB.NFXNREQ.041.json)

