# C4 Assess history of prior TB treatment - TTL Representation - SMART DAK TB v1.0.2

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **C4 Assess history of prior TB treatment**

## : C4 Assess history of prior TB treatment - TTL Representation

| |
| :--- |
| Active as of 2026-11-18 |

[Raw ttl](Requirements-TB.FXNREQ.028.C.ttl) | [Download](Requirements-TB.FXNREQ.028.C.ttl)

