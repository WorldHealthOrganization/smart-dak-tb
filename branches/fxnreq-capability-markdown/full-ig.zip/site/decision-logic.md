# Decision-support logic - SMART DAK TB v1.0.2

* [**Table of Contents**](toc.md)
* [**Business Requirements**](business-requirements.md)
* **Decision-support logic**

## Decision-support logic

| | |
| :--- | :--- |
| current* | [TB DAK_decision-support logic.xlsx](TB DAK_decision-support logic.xlsx) |
| 1.0.0 | [TB DAK_decision-support logic.xlsx](https://smart.who.int/dak-tb/v1.0.0/TB DAK_decision-support logic.xlsx) |
| 0.9.9 | [TB DAK_decision-support logic.xlsx](https://smart.who.int/dak-tb/v0.9.9/TB DAK_decision-support logic.xlsx) |

*The current link indicates the latest release of the file. Note: the file's latest release might not always match the release number of the Implementation Guide.

