# Health worker or data entry clerk or medical office receptionist - JSON Representation - SMART DAK TB v1.0.2

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Health worker or data entry clerk or medical office receptionist**

## : Health worker or data entry clerk or medical office receptionist - JSON Representation

| |
| :--- |
| Active as of 2026-11-18 |

[Raw json](ActorDefinition-healthworkerordataentryclerkormedicalofficereceptionist.json) | [Download](ActorDefinition-healthworkerordataentryclerkormedicalofficereceptionist.json)

