# Provide a mechanism to securely change a user's password - JSON Representation - SMART DAK TB v1.0.2

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Provide a mechanism to securely change a user's password**

## : Provide a mechanism to securely change a user's password - JSON Representation

| |
| :--- |
| Active as of 2026-11-18 |

[Raw json](Requirements-TB.NFXNREQ.011.json) | [Download](Requirements-TB.NFXNREQ.011.json)

