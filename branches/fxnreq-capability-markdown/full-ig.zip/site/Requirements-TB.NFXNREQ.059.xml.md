# Adjust display to fit small screens (e.g. mobile phones) - XML Representation - SMART DAK TB v1.0.2

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Adjust display to fit small screens (e.g. mobile phones)**

## : Adjust display to fit small screens (e.g. mobile phones) - XML Representation

| |
| :--- |
| Active as of 2026-11-18 |

[Raw xml](Requirements-TB.NFXNREQ.059.xml) | [Download](Requirements-TB.NFXNREQ.059.xml)

