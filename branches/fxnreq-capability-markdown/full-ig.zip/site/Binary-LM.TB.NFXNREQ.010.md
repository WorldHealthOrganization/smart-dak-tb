# LM.TB.NFXNREQ.010 - SMART DAK TB v1.0.2

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **LM.TB.NFXNREQ.010**

## Binary: LM.TB.NFXNREQ.010

```

{
  "resourceType": "http://smart.who.int/base/StructureDefinition/NonFunctionalRequirement",
  "id": "LM.TB.NFXNREQ.010",
  "requirement": "Adhere to complex password requirements",
  "category": {
    "code": "Securityauthentication",
    "system": "http://smart.who.int/dak-tb/CodeSystem/FXREQCategories"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
