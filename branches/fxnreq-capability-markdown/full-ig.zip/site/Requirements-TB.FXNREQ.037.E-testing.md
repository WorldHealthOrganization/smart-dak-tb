#  Offer TB prevention counselling - Testing - SMART DAK TB v1.0.2

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* ** Offer TB prevention counselling**

## Requirements: Offer TB prevention counselling - Testing (Experimental) 

| |
| :--- |
| Active as of 2026-11-18 |

### Test Plans

**No test plans are currently available for the Requirements.**

### Test Scripts

**No test scripts are currently available for the Requirements.**

