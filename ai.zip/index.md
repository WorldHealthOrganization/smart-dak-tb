# Home - SMART DAK TB v1.0.2

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/dak-tb/ImplementationGuide/smart.who.int.dak-tb | *Version*:1.0.2 |
| Draft as of 2024-07-17 | *Computable Name*:DakTb |

### Summary

The WHO Global Tuberculosis Programme (GTB) works towards the goal of a world free of TB, with zero deaths, disease and suffering due to the disease. One of its core functions is to develop policy options, norms and standards for TB prevention and care and facilitate their implementation. The five-step pathway to advance the adoption of best clinical and data practices for TB is presented below.

### L1 Narrative guidelines

To guide national TB programmes in the efforts of ending the TB epidemic, GTB releases narrative guidelines on TB prevention, diagnosis and treatment based on latest available evidence. In addition to these guidelines, GTB also releases various guidance documents including TB surveillance guidance. These guidelines and guidance documents informed the development of the digital adaptation kit for TB (DAK for TB). The WHO consolidated guidelines on TB can be found [here](https://tbksp.org/en), and the WHO TB surveillance guidance can be found [here](https://iris.who.int/handle/10665/376612).

### L2 Operational guidelines

Digital adaptation kits are designed to facilitate the accurate reflection of WHO’s clinical, public health and data use guidelines within the digital systems countries are adopting. DAKs are operational, software-agnostic, standardized documentation that distil clinical, public health and data use guidance into a format that can be transparently incorporated into digital systems. DAKs serve as a prerequisite for developing computable, or machine-readable, guidelines, as well as executable reference software and advanced analytics for precision health.

The DAK for TB and the associated implementation tools can be found here:

* [Published DAK Document](https://iris.who.int/handle/10665/376631)
* Implementation tools:

### L3 Machine readable guidelines

The L3 FHIR Implementation Guide for the TB SMART Guidelines is yet to be developed. Links will be published here as soon as they are available.

### L4 Executable guidelines

Reference implementations representing the L4 layer for the TB SMART Guidelines are not yet available. Links will be published here as soon as they're available.

### L5 Dynamic guidelines

Content representing the L5 layer for the TB SMART Guidelines are not yet available. Links will be published here as soon as they're available.

### Contact Us

Please let us know about your experience in using the DAK and questions you may have by contacting us at [SMART@who.int](mailto:SMART@who.int?subject = DAK Feedback)

### License

This work is licensed under a [Creative Commons Attribution-NonCommercial-ShareAlike 3.0 IGO License](http://creativecommons.org/licenses/by-nc-sa/3.0/igo/).

![](https://i.creativecommons.org/l/by-nc-sa/3.0/igo/88x31.png)

### Providing Feedback

 Feedback specific to this specification can provided through: 

* Clicking on one of the Feedbacks link to the right of any section header
* Sending an email to [SMART@who.int](mailto:SMART@who.int?subject = DAK Feedback)
* Creating an issue on GitHub [dak-tb repository](https://github.com/WorldHealthOrganization/smart-dak-tb)

### Disclaimer

The specification herewith documented is a demo working specification and may not be used for any implementation purposes. This draft is provided without warranty of completeness or consistency and the official publication supersedes this draft. No liability can be inferred from the use or misuse of this specification or its consequences.

