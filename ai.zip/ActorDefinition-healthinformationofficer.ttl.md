# Health information officer - TTL Representation - SMART DAK TB v1.0.2

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Health information officer**

## : Health information officer - TTL Representation

| |
| :--- |
| Active as of 2026-11-19 |

[Raw ttl](ActorDefinition-healthinformationofficer.ttl) | [Download](ActorDefinition-healthinformationofficer.ttl)

