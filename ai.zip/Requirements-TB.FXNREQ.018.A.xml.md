#  Check in the client - XML Representation - SMART DAK TB v1.0.2

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* ** Check in the client**

## : Check in the client - XML Representation

| |
| :--- |
| Active as of 2026-11-19 |

[Raw xml](Requirements-TB.FXNREQ.018.A.xml) | [Download](Requirements-TB.FXNREQ.018.A.xml)

