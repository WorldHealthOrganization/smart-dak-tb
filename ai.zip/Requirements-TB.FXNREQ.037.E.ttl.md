#  Offer TB prevention counselling - TTL Representation - SMART DAK TB v1.0.2

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* ** Offer TB prevention counselling**

## : Offer TB prevention counselling - TTL Representation

| |
| :--- |
| Active as of 2026-11-19 |

[Raw ttl](Requirements-TB.FXNREQ.037.E.ttl) | [Download](Requirements-TB.FXNREQ.037.E.ttl)

