#  Schedule the follow-up visit - JSON Representation - SMART DAK TB v1.0.2

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* ** Schedule the follow-up visit**

## : Schedule the follow-up visit - JSON Representation

| |
| :--- |
| Active as of 2026-11-19 |

[Raw json](Requirements-TB.FXNREQ.043.E.json) | [Download](Requirements-TB.FXNREQ.043.E.json)

