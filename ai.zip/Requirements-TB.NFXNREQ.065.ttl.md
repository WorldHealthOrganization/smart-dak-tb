# Provide access to data through application programming interfaces - TTL Representation - SMART DAK TB v1.0.2

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Provide access to data through application programming interfaces**

## : Provide access to data through application programming interfaces - TTL Representation

| |
| :--- |
| Active as of 2026-11-19 |

[Raw ttl](Requirements-TB.NFXNREQ.065.ttl) | [Download](Requirements-TB.NFXNREQ.065.ttl)

