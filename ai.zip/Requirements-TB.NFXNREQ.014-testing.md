# Lock a user out after a specified number of wrong password attempts - Testing - SMART DAK TB v1.0.2

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Lock a user out after a specified number of wrong password attempts**

## Requirements: Lock a user out after a specified number of wrong password attempts - Testing (Experimental) 

| |
| :--- |
| Active as of 2026-11-19 |

### Test Plans

**No test plans are currently available for the Requirements.**

### Test Scripts

**No test scripts are currently available for the Requirements.**

